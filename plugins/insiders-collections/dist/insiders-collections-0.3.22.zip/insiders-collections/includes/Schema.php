<?php
namespace Insiders\Collections;

use Insiders\Collections\Domain\Templates;
use Insiders\Collections\Support\Db;

defined( 'ABSPATH' ) || exit;

/**
 * Custom tables, created with explicit SQL and checked through information_schema.
 *
 * Why not user_meta (the house default): the ledger needs UNIQUE constraints and
 * row locks to guarantee "one payment, one allocation" under concurrent webhooks.
 * Why not dbDelta: it reports nothing when it skips an index or a column, and
 * it broke a site once. Every statement here is idempotent.
 *
 * DATETIME columns are NULL-able and written from PHP in UTC; DEFAULT
 * CURRENT_TIMESTAMP fails on older MariaDB.
 */
final class Schema {

	public static function tables(): array {
		return array(
			'customers' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				wp_user_id BIGINT UNSIGNED NULL,
				full_name VARCHAR(190) NOT NULL DEFAULT '',
				first_name VARCHAR(100) NULL,
				first_name_reliable TINYINT(1) NOT NULL DEFAULT 0,
				phone_e164 VARCHAR(20) NULL,
				email VARCHAR(190) NULL,
				contact_status VARCHAR(20) NOT NULL DEFAULT 'unverified',
				contact_verified_at DATETIME NULL,
				owner_id BIGINT UNSIGNED NULL,
				pipedrive_person_id BIGINT UNSIGNED NULL,
				notes TEXT NULL,
				conversation_owner VARCHAR(20) NOT NULL DEFAULT 'none',
				conversation_owner_at DATETIME NULL,
				last_inbound_at DATETIME NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY phone (phone_e164),
				KEY wp_user (wp_user_id),
				KEY email (email)",
			'external_identities' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NOT NULL,
				provider VARCHAR(30) NOT NULL,
				tenant_or_terminal VARCHAR(64) NOT NULL DEFAULT '',
				external_id VARCHAR(128) NOT NULL,
				verified_at DATETIME NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY ident (provider, tenant_or_terminal, external_id),
				KEY customer (customer_id)",
			'agreements' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NOT NULL,
				type VARCHAR(30) NOT NULL,
				program VARCHAR(100) NULL,
				reference VARCHAR(190) NULL,
				signed_at DATE NULL,
				joined_at DATE NULL,
				document_ref VARCHAR(255) NULL,
				account_open_deadline DATE NULL,
				extensions_json TEXT NULL,
				status_checked_at DATE NULL,
				pipedrive_deal_id BIGINT UNSIGNED NULL,
				price_total_minor BIGINT NULL,
				fee_credit_minor BIGINT NULL,
				no_registration_fee TINYINT(1) NOT NULL DEFAULT 0,
				deal_status VARCHAR(12) NULL,
				lost_reason VARCHAR(190) NULL,
				deal_checked_at DATETIME NULL,
				billing_policy_version INT NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY customer (customer_id)",
			'recurring_orders' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NOT NULL,
				agreement_id BIGINT UNSIGNED NULL,
				terminal VARCHAR(64) NOT NULL,
				sto_id VARCHAR(64) NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				next_due_at DATE NULL,
				charge_dom TINYINT UNSIGNED NULL,
				first_charge_date DATE NULL,
				charge_amount_minor BIGINT NULL,
				future_installments INT NULL,
				future_balance_minor BIGINT NULL,
				currency CHAR(3) NOT NULL DEFAULT 'ILS',
				card_status VARCHAR(30) NOT NULL DEFAULT 'unknown',
				card_status_basis VARCHAR(190) NULL,
				card_last4 CHAR(4) NULL,
				card_expiry VARCHAR(7) NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY sto (terminal, sto_id),
				KEY customer (customer_id),
				KEY card_status (card_status)",
			// The standing-order book for the cash forecast: amounts and schedule only, no name, token or card number.
			'sto_book' => "
				terminal VARCHAR(64) NOT NULL,
				sto_id VARCHAR(64) NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				charge_amount_minor BIGINT NULL,
				currency CHAR(3) NOT NULL DEFAULT 'ILS',
				vat_percent DECIMAL(5,2) NULL,
				frequency VARCHAR(20) NOT NULL DEFAULT '',
				charge_dom TINYINT UNSIGNED NULL,
				payments_number INT NULL,
				first_charge_date DATE NULL,
				next_charge_date DATE NULL,
				last_charge_date DATE NULL,
				card_expiry CHAR(7) NULL,
				token_hash CHAR(64) NULL,
				seen_at DATETIME NULL,
				PRIMARY KEY (terminal, sto_id),
				KEY status (status)",
			'cases' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NOT NULL,
				agreement_id BIGINT UNSIGNED NULL,
				recurring_order_id BIGINT UNSIGNED NULL,
				case_key VARCHAR(100) NOT NULL,
				active_key VARCHAR(100) NULL,
				source_type VARCHAR(30) NOT NULL,
				entry_mode VARCHAR(20) NOT NULL DEFAULT 'new',
				phase VARCHAR(12) NOT NULL DEFAULT 'charge',
				track VARCHAR(20) NULL,
				track_step VARCHAR(30) NULL,
				declined_at DATETIME NULL,
				declined_source VARCHAR(20) NULL,
				workflow_state VARCHAR(30) NOT NULL DEFAULT 'draft',
				state_reason VARCHAR(255) NULL,
				owner_id BIGINT UNSIGNED NULL,
				currency CHAR(3) NOT NULL DEFAULT 'ILS',
				history_mode VARCHAR(20) NOT NULL DEFAULT 'none',
				opening_balance_as_of DATETIME NULL,
				clarification_first TINYINT(1) NOT NULL DEFAULT 0,
				sequence_step INT NOT NULL DEFAULT 0,
				sequence_started_at DATETIME NULL,
				broken_promises INT NOT NULL DEFAULT 0,
				last_outbound_at DATETIME NULL,
				last_inbound_at DATETIME NULL,
				next_action_type VARCHAR(40) NULL,
				next_action_at DATETIME NULL,
				dispute_open TINYINT(1) NOT NULL DEFAULT 0,
				claims_account_opened TINYINT(1) NOT NULL DEFAULT 0,
				version INT UNSIGNED NOT NULL DEFAULT 1,
				created_by BIGINT UNSIGNED NULL,
				activated_by BIGINT UNSIGNED NULL,
				activated_at DATETIME NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				closed_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY active_key (active_key),
				KEY state_next (workflow_state, next_action_at),
				KEY phase (phase, workflow_state),
				KEY customer (customer_id),
				KEY owner (owner_id)",
			'debt_items' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				case_id BIGINT UNSIGNED NOT NULL,
				source_key VARCHAR(190) NULL,
				description VARCHAR(255) NOT NULL DEFAULT '',
				due_at DATE NOT NULL,
				original_amount_minor BIGINT NOT NULL,
				currency CHAR(3) NOT NULL DEFAULT 'ILS',
				finance_state VARCHAR(20) NOT NULL DEFAULT 'draft',
				collection_owner VARCHAR(30) NOT NULL DEFAULT 'manual',
				is_opening_balance TINYINT(1) NOT NULL DEFAULT 0,
				approval_basis TEXT NULL,
				evidence_ref VARCHAR(255) NULL,
				approved_by BIGINT UNSIGNED NULL,
				approved_at DATETIME NULL,
				review_reason VARCHAR(255) NULL,
				cached_balance_minor BIGINT NOT NULL DEFAULT 0,
				balance_version INT UNSIGNED NOT NULL DEFAULT 1,
				settled_at DATETIME NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY source_key (source_key),
				KEY case_id (case_id),
				KEY state_due (finance_state, due_at)",
			'charge_attempts' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				debt_item_id BIGINT UNSIGNED NULL,
				recurring_order_id BIGINT UNSIGNED NULL,
				terminal VARCHAR(64) NOT NULL,
				transaction_index VARCHAR(64) NOT NULL,
				response_code VARCHAR(10) NOT NULL DEFAULT '',
				failure_class VARCHAR(30) NOT NULL DEFAULT '',
				amount_minor BIGINT NULL,
				currency CHAR(3) NULL,
				cycle_ref VARCHAR(100) NULL,
				occurred_at DATETIME NULL,
				inbox_event_id BIGINT UNSIGNED NULL,
				verification_state VARCHAR(20) NOT NULL DEFAULT 'unverified',
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY attempt (terminal, transaction_index),
				KEY item (debt_item_id)",
			'payments' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				provider VARCHAR(30) NOT NULL,
				terminal VARCHAR(64) NOT NULL DEFAULT '',
				transaction_id VARCHAR(64) NOT NULL,
				customer_id BIGINT UNSIGNED NULL,
				recurring_order_id BIGINT UNSIGNED NULL,
				payment_request_id BIGINT UNSIGNED NULL,
				amount_minor BIGINT NOT NULL,
				currency CHAR(3) NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'verified',
				tran_type VARCHAR(20) NOT NULL DEFAULT 'charge',
				origin VARCHAR(20) NOT NULL DEFAULT 'manual',
				payment_method VARCHAR(20) NOT NULL DEFAULT 'unknown',
				has_reusable_token TINYINT(1) NOT NULL DEFAULT 0,
				card_last4 CHAR(4) NULL,
				card_expiry VARCHAR(7) NULL,
				cycle_ref VARCHAR(100) NULL,
				occurred_at DATETIME NULL,
				verified_at DATETIME NULL,
				verified_by BIGINT UNSIGNED NULL,
				verification_source VARCHAR(30) NULL,
				evidence_ref VARCHAR(255) NULL,
				document_ref VARCHAR(190) NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY txn (provider, terminal, transaction_id),
				KEY customer (customer_id),
				KEY request (payment_request_id)",
			'allocations' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				payment_id BIGINT UNSIGNED NOT NULL,
				debt_item_id BIGINT UNSIGNED NOT NULL,
				amount_minor BIGINT NOT NULL,
				reversal_of BIGINT UNSIGNED NULL,
				reason VARCHAR(255) NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY reversal (reversal_of),
				KEY payment (payment_id),
				KEY item (debt_item_id)",
			'adjustments' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				debt_item_id BIGINT UNSIGNED NOT NULL,
				type VARCHAR(30) NOT NULL,
				amount_minor BIGINT NOT NULL,
				reason VARCHAR(500) NOT NULL,
				evidence_ref VARCHAR(255) NULL,
				approved_by BIGINT UNSIGNED NOT NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY item (debt_item_id)",
			'payment_requests' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				case_id BIGINT UNSIGNED NOT NULL,
				token_hash CHAR(64) NOT NULL,
				token_enc TEXT NULL,
				provider_pr_id VARCHAR(100) NULL,
				provider_url_enc TEXT NULL,
				amount_minor BIGINT NOT NULL,
				currency CHAR(3) NOT NULL,
				balance_version VARCHAR(190) NOT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'draft',
				expires_at DATETIME NULL,
				opened_at DATETIME NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY token (token_hash),
				KEY case_status (case_id, status)",
			'request_items' => "
				payment_request_id BIGINT UNSIGNED NOT NULL,
				debt_item_id BIGINT UNSIGNED NOT NULL,
				requested_amount_minor BIGINT NOT NULL,
				PRIMARY KEY (payment_request_id, debt_item_id)",
			'promises' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				case_id BIGINT UNSIGNED NOT NULL,
				amount_minor BIGINT NULL,
				promised_at DATE NOT NULL,
				state VARCHAR(20) NOT NULL DEFAULT 'requested',
				source VARCHAR(20) NOT NULL DEFAULT 'user',
				source_message_id BIGINT UNSIGNED NULL,
				note VARCHAR(500) NULL,
				approved_by BIGINT UNSIGNED NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				resolved_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY case_state (case_id, state)",
			'messages' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NULL,
				case_id BIGINT UNSIGNED NULL,
				provider VARCHAR(20) NOT NULL DEFAULT 'wati',
				provider_id VARCHAR(128) NULL,
				local_id CHAR(36) NOT NULL,
				direction VARCHAR(4) NOT NULL,
				channel VARCHAR(20) NOT NULL DEFAULT 'whatsapp',
				kind VARCHAR(30) NOT NULL DEFAULT 'collection_reminder',
				template_key VARCHAR(60) NULL,
				template_version INT NULL,
				body TEXT NULL,
				vars_json TEXT NULL,
				author_type VARCHAR(20) NOT NULL DEFAULT 'system',
				author_id BIGINT UNSIGNED NULL,
				delivery_state VARCHAR(20) NOT NULL DEFAULT 'draft',
				counts_toward_quota TINYINT(1) NOT NULL DEFAULT 0,
				intent VARCHAR(40) NULL,
				intent_source VARCHAR(10) NULL,
				is_internal TINYINT(1) NOT NULL DEFAULT 0,
				occurred_at DATETIME NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY local_id (local_id),
				UNIQUE KEY provider_msg (provider, provider_id),
				KEY customer_time (customer_id, occurred_at),
				KEY case_id (case_id),
				KEY delivery (delivery_state)",
			'imported_history' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				case_id BIGINT UNSIGNED NOT NULL,
				original_at DATETIME NULL,
				author_label VARCHAR(100) NULL,
				channel VARCHAR(20) NULL,
				content MEDIUMTEXT NULL,
				content_ref VARCHAR(255) NULL,
				import_mode VARCHAR(20) NOT NULL,
				entry_type VARCHAR(20) NOT NULL DEFAULT 'note',
				amount_minor BIGINT NULL,
				affects_opening_balance TINYINT(1) NOT NULL DEFAULT 0,
				counts_toward_quota TINYINT(1) NOT NULL DEFAULT 0,
				entered_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY case_id (case_id)",
			'scheduled_actions' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				case_id BIGINT UNSIGNED NULL,
				customer_id BIGINT UNSIGNED NULL,
				type VARCHAR(40) NOT NULL,
				run_at DATETIME NOT NULL,
				state VARCHAR(20) NOT NULL DEFAULT 'pending',
				policy_version INT NULL,
				idempotency_key VARCHAR(190) NOT NULL,
				payload TEXT NULL,
				claimed_by VARCHAR(40) NULL,
				claimed_until DATETIME NULL,
				attempts INT NOT NULL DEFAULT 0,
				last_error VARCHAR(500) NULL,
				result VARCHAR(500) NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY idem (idempotency_key),
				KEY due (state, run_at),
				KEY case_id (case_id)",
			'card_update_tasks' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				recurring_order_id BIGINT UNSIGNED NOT NULL,
				source_payment_id BIGINT UNSIGNED NOT NULL,
				state VARCHAR(30) NOT NULL DEFAULT 'open',
				due_at DATETIME NULL,
				urgency VARCHAR(10) NOT NULL DEFAULT 'normal',
				assigned_to BIGINT UNSIGNED NULL,
				confirmation_type VARCHAR(30) NULL,
				confirmation_ref VARCHAR(255) NULL,
				confirmed_by BIGINT UNSIGNED NULL,
				confirmed_at DATETIME NULL,
				note VARCHAR(500) NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY order_payment (recurring_order_id, source_payment_id),
				KEY state_due (state, due_at)",
			'card_credentials' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				terminal VARCHAR(64) NOT NULL,
				encrypted_token TEXT NOT NULL,
				expiry_month TINYINT UNSIGNED NULL,
				expiry_year SMALLINT UNSIGNED NULL,
				last4 CHAR(4) NULL,
				source_payment_id BIGINT UNSIGNED NULL,
				fingerprint CHAR(64) NOT NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY fp (fingerprint),
				KEY payment (source_payment_id)",
			'inbox_events' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				provider VARCHAR(20) NOT NULL,
				integration_id VARCHAR(64) NOT NULL DEFAULT '',
				provider_event_key CHAR(64) NOT NULL,
				payload_enc MEDIUMTEXT NULL,
				payload_redacted MEDIUMTEXT NULL,
				content_type VARCHAR(100) NULL,
				occurred_at DATETIME NULL,
				received_at DATETIME NULL,
				processing_state VARCHAR(20) NOT NULL DEFAULT 'received',
				attempts INT NOT NULL DEFAULT 0,
				last_error VARCHAR(500) NULL,
				processed_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY event_key (provider, provider_event_key),
				KEY pending (processing_state, received_at)",
			'outbox_events' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				event_type VARCHAR(40) NOT NULL,
				aggregate_type VARCHAR(30) NOT NULL DEFAULT '',
				aggregate_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				idempotency_key VARCHAR(190) NOT NULL,
				payload MEDIUMTEXT NULL,
				state VARCHAR(20) NOT NULL DEFAULT 'pending',
				next_attempt_at DATETIME NULL,
				attempts INT NOT NULL DEFAULT 0,
				last_error VARCHAR(500) NULL,
				result MEDIUMTEXT NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY idem (idempotency_key),
				KEY pending (state, next_attempt_at)",
			'audit_log' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				actor_type VARCHAR(10) NOT NULL,
				actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				action VARCHAR(60) NOT NULL,
				entity_type VARCHAR(30) NOT NULL,
				entity_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				before_json MEDIUMTEXT NULL,
				after_json MEDIUMTEXT NULL,
				reason VARCHAR(1000) NULL,
				occurred_at DATETIME NULL,
				correlation_id CHAR(36) NULL,
				PRIMARY KEY (id),
				KEY entity (entity_type, entity_id),
				KEY occurred (occurred_at)",
			'contact_preferences' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				customer_id BIGINT UNSIGNED NOT NULL,
				channel VARCHAR(20) NOT NULL,
				allowed TINYINT(1) NOT NULL DEFAULT 1,
				source VARCHAR(190) NULL,
				captured_at DATETIME NULL,
				revoked_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY cust_channel (customer_id, channel)",
			'policies' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				version INT UNSIGNED NOT NULL,
				effective_at DATETIME NULL,
				approved_by BIGINT UNSIGNED NULL,
				approved_at DATETIME NULL,
				config MEDIUMTEXT NOT NULL,
				note VARCHAR(500) NULL,
				created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY version (version)",
			'integration_tasks' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				destination VARCHAR(20) NOT NULL,
				internal_task_key VARCHAR(190) NOT NULL,
				external_task_id VARCHAR(64) NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'pending',
				last_error VARCHAR(500) NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY task_key (destination, internal_task_key)",
			'tasks' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				task_key VARCHAR(190) NOT NULL,
				type VARCHAR(40) NOT NULL,
				case_id BIGINT UNSIGNED NULL,
				customer_id BIGINT UNSIGNED NULL,
				assigned_to BIGINT UNSIGNED NULL,
				due_at DATETIME NULL,
				priority VARCHAR(10) NOT NULL DEFAULT 'normal',
				reason VARCHAR(500) NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'open',
				repeat_count INT NOT NULL DEFAULT 0,
				resolution_note VARCHAR(500) NULL,
				resolved_by BIGINT UNSIGNED NULL,
				resolved_at DATETIME NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY task_key (task_key),
				KEY open_due (status, due_at),
				KEY assignee (assigned_to, status)",
			'exceptions' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				exception_key VARCHAR(190) NOT NULL,
				type VARCHAR(40) NOT NULL,
				severity VARCHAR(10) NOT NULL DEFAULT 'medium',
				owner_id BIGINT UNSIGNED NULL,
				entity_type VARCHAR(30) NULL,
				entity_id BIGINT UNSIGNED NULL,
				customer_id BIGINT UNSIGNED NULL,
				inbox_event_id BIGINT UNSIGNED NULL,
				summary VARCHAR(500) NOT NULL,
				details MEDIUMTEXT NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'open',
				resolution VARCHAR(1000) NULL,
				resolved_by BIGINT UNSIGNED NULL,
				opened_at DATETIME NULL,
				resolved_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY ex_key (exception_key),
				KEY open_type (status, type)",
			'idempotency' => "
				idem_key CHAR(64) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				route VARCHAR(190) NOT NULL,
				request_hash CHAR(64) NOT NULL,
				status_code SMALLINT NOT NULL,
				response MEDIUMTEXT NULL,
				created_at DATETIME NULL,
				PRIMARY KEY (idem_key)",
			'program_candidates' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				wp_user_id BIGINT UNSIGNED NULL,
				source VARCHAR(20) NULL,
				pipedrive_person_id BIGINT UNSIGNED NULL,
				pipedrive_deal_id BIGINT UNSIGNED NULL,
				candidate_key VARCHAR(190) NOT NULL,
				deadline DATE NULL,
				status VARCHAR(20) NOT NULL DEFAULT 'new',
				case_id BIGINT UNSIGNED NULL,
				note VARCHAR(500) NULL,
				decided_by BIGINT UNSIGNED NULL,
				snapshot TEXT NULL,
				created_at DATETIME NULL,
				updated_at DATETIME NULL,
				PRIMARY KEY (id),
				UNIQUE KEY cand (candidate_key),
				KEY user_id (wp_user_id),
				KEY person (pipedrive_person_id)",
			// Security gate (QR + passkey). Devices are phones; a session exists only after a phone approved it.
			'gate_devices' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL,
				credential_id VARCHAR(255) NOT NULL,
				public_key TEXT NOT NULL,
				alg SMALLINT NOT NULL,
				sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
				aaguid CHAR(36) NULL,
				backup_eligible TINYINT(1) NOT NULL DEFAULT 0,
				label VARCHAR(100) NOT NULL,
				status VARCHAR(12) NOT NULL DEFAULT 'pending',
				created_at DATETIME NULL,
				confirmed_at DATETIME NULL,
				approved_at DATETIME NULL,
				approved_by BIGINT UNSIGNED NULL,
				last_used_at DATETIME NULL,
				revoked_at DATETIME NULL,
				revoked_by BIGINT UNSIGNED NULL,
				PRIMARY KEY (id),
				UNIQUE KEY cred (credential_id),
				KEY user_status (user_id, status)",
			'gate_challenges' => "
				id CHAR(32) NOT NULL,
				kind VARCHAR(10) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				wp_session_hash CHAR(64) NOT NULL,
				challenge VARCHAR(64) NOT NULL,
				match_code TINYINT UNSIGNED NULL,
				pair_code_hash CHAR(64) NULL,
				attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
				status VARCHAR(12) NOT NULL DEFAULT 'pending',
				device_id BIGINT UNSIGNED NULL,
				ip VARCHAR(45) NULL,
				user_agent VARCHAR(255) NULL,
				created_at DATETIME NULL,
				expires_at DATETIME NULL,
				approved_at DATETIME NULL,
				PRIMARY KEY (id),
				KEY user_kind (user_id, kind, status)",
			'gate_sessions' => "
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				token_hash CHAR(64) NOT NULL,
				user_id BIGINT UNSIGNED NOT NULL,
				wp_session_hash CHAR(64) NOT NULL,
				device_id BIGINT UNSIGNED NULL,
				ip VARCHAR(45) NULL,
				user_agent VARCHAR(255) NULL,
				created_at DATETIME NULL,
				last_seen_at DATETIME NULL,
				expires_at DATETIME NULL,
				revoked_at DATETIME NULL,
				revoke_reason VARCHAR(40) NULL,
				PRIMARY KEY (id),
				UNIQUE KEY token (token_hash),
				KEY user_open (user_id, revoked_at)",
		);
	}

	public static function install(): array {
		global $wpdb;
		$report  = array();
		$charset = $wpdb->get_charset_collate();
		foreach ( self::tables() as $name => $columns ) {
			$table = Db::t( $name );
			$sql   = "CREATE TABLE IF NOT EXISTS `{$table}` ( {$columns} ) ENGINE=InnoDB {$charset}";
			$ok    = $wpdb->query( $sql );
			$report[ $name ] = ( false === $ok ) ? 'error: ' . $wpdb->last_error : 'ok';
		}
		$report['upgrade'] = self::upgrade();
		if ( ! in_array( false, $report['upgrade'], true ) ) {
			// Only a complete upgrade moves the version; a failed ALTER is retried on the next load.
			update_option( 'icol_db_version', ICOL_DB_VERSION, false );
		}
		return $report;
	}

	/**
	 * CREATE TABLE IF NOT EXISTS never alters an existing table, so columns added
	 * after v1 are checked one by one in information_schema and added explicitly.
	 */
	private static function upgrade(): array {
		global $wpdb;
		$out = array(
			'program_candidates.source'              => self::ensure_column( 'program_candidates', 'source', 'VARCHAR(20) NULL AFTER wp_user_id' ),
			'program_candidates.pipedrive_person_id' => self::ensure_column( 'program_candidates', 'pipedrive_person_id', 'BIGINT UNSIGNED NULL AFTER source' ),
			'program_candidates.pipedrive_deal_id'   => self::ensure_column( 'program_candidates', 'pipedrive_deal_id', 'BIGINT UNSIGNED NULL AFTER pipedrive_person_id' ),
			'agreements.pipedrive_deal_id'           => self::ensure_column( 'agreements', 'pipedrive_deal_id', 'BIGINT UNSIGNED NULL AFTER status_checked_at' ),
			// v3: the pre-deadline journey (commitment phase) and the price rule.
			'agreements.price_total_minor'           => self::ensure_column( 'agreements', 'price_total_minor', 'BIGINT NULL AFTER pipedrive_deal_id' ),
			'agreements.fee_credit_minor'            => self::ensure_column( 'agreements', 'fee_credit_minor', 'BIGINT NULL AFTER price_total_minor' ),
			'agreements.no_registration_fee'         => self::ensure_column( 'agreements', 'no_registration_fee', 'TINYINT(1) NOT NULL DEFAULT 0 AFTER fee_credit_minor' ),
			'agreements.deal_status'                 => self::ensure_column( 'agreements', 'deal_status', 'VARCHAR(12) NULL AFTER no_registration_fee' ),
			'agreements.lost_reason'                 => self::ensure_column( 'agreements', 'lost_reason', 'VARCHAR(190) NULL AFTER deal_status' ),
			'agreements.deal_checked_at'             => self::ensure_column( 'agreements', 'deal_checked_at', 'DATETIME NULL AFTER lost_reason' ),
			// Existing cases are all in the charge phase: the column default says so.
			'cases.phase'                            => self::ensure_column( 'cases', 'phase', "VARCHAR(12) NOT NULL DEFAULT 'charge' AFTER entry_mode" ),
			'cases.track'                            => self::ensure_column( 'cases', 'track', 'VARCHAR(20) NULL AFTER phase' ),
			'cases.track_step'                       => self::ensure_column( 'cases', 'track_step', 'VARCHAR(30) NULL AFTER track' ),
			'cases.declined_at'                      => self::ensure_column( 'cases', 'declined_at', 'DATETIME NULL AFTER track_step' ),
			'cases.declined_source'                  => self::ensure_column( 'cases', 'declined_source', 'VARCHAR(20) NULL AFTER declined_at' ),
		);
		$out['cases.phase_index'] = self::ensure_index( 'cases', 'phase', '(phase, workflow_state)' );
		// v1 had wp_user_id NOT NULL; candidates from the finance dashboard are keyed by Pipedrive person.
		$table    = Db::t( 'program_candidates' );
		$nullable = $wpdb->get_var( $wpdb->prepare( 'SELECT IS_NULLABLE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s', $table, 'wp_user_id' ) );
		$out['program_candidates.wp_user_id_null'] = 'NO' === $nullable ? false !== $wpdb->query( "ALTER TABLE `{$table}` MODIFY wp_user_id BIGINT UNSIGNED NULL" ) : true;
		$out['program_candidates.person_index'] = self::ensure_index( 'program_candidates', 'person', '(pipedrive_person_id)' );
		// v4: the money variables carry the ₪ sign; stored bodies lose the sign they used to add after it.
		$out['templates.currency_sign'] = Templates::strip_currency_sign();
		// v5: the transaction report returns agorot. 'major' was the form's first option, never a verified choice.
		if ( 'major' === ( \Insiders\Collections\Support\Settings::all()['tranzila_report_amount_unit'] ?? null ) ) {
			\Insiders\Collections\Support\Settings::set( array( 'tranzila_report_amount_unit' => 'minor' ) );
			\Insiders\Collections\Support\Audit::log( 'settings.report_amount_unit', 'system', 0, array( 'unit' => 'major' ), array( 'unit' => 'minor' ), 'שדרוג: דוח העסקאות של טרנזילה מחזיר אגורות (100 ₪ = 10000)' );
		}
		$out['settings.report_amount_unit'] = true;
		// v7: a declined charge in the report finds its standing order by the token's hash.
		$out['sto_book.token_hash'] = self::ensure_column( 'sto_book', 'token_hash', 'CHAR(64) NULL AFTER card_expiry' );
		// v8: standing orders are mapped to customers automatically; events that waited for a manual mapping go round again.
		if ( (int) get_option( 'icol_db_version', 0 ) < 8 ) {
			$wpdb->query( 'UPDATE ' . Db::t( 'inbox_events' ) . " SET processing_state = 'received' WHERE provider = 'tranzila' AND processing_state = 'needs_match' AND payload_redacted LIKE '%sto_external_id%'" );
		}
		$out['inbox.sto_requeue'] = true;
		// v9/v10: cases an unrelated inbound message, or a message another team typed in WATI, sent to a
		// person before anything was really sent go back. A data repair never blocks the schema upgrade.
		if ( (int) get_option( 'icol_db_version', 0 ) < 10 ) {
			try {
				\Insiders\Collections\Domain\Journey::relabel_team_messages();
				\Insiders\Collections\Domain\Journey::repair_unprompted_reviews();
			} catch ( \Throwable $e ) {
				error_log( '[ICOL] upgrade repair failed: ' . $e->getMessage() );
			}
		}
		$out['cases.unprompted_reviews'] = true;
		return $out;
	}

	private static function ensure_index( string $name, string $index, string $columns ): bool {
		global $wpdb;
		$table = Db::t( $name );
		$have  = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = %s', $table, $index ) );
		return (int) $have > 0 ? true : false !== $wpdb->query( "ALTER TABLE `{$table}` ADD KEY `{$index}` {$columns}" );
	}

	/** Verifies every table exists and is InnoDB (transactions + row locks depend on it). */
	public static function verify(): array {
		global $wpdb;
		$out = array();
		foreach ( array_keys( self::tables() ) as $name ) {
			$table = Db::t( $name );
			$row   = $wpdb->get_row(
				$wpdb->prepare( 'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s', $table ),
				ARRAY_A
			);
			$out[ $name ] = $row ? ( 'InnoDB' === $row['ENGINE'] ? 'ok' : 'engine=' . $row['ENGINE'] ) : 'missing';
		}
		return $out;
	}

	/** For future migrations: explicit, idempotent ALTER after an information_schema check. */
	public static function ensure_column( string $name, string $column, string $definition ): bool {
		global $wpdb;
		$table  = Db::t( $name );
		$exists = $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s', $table, $column )
		);
		if ( (int) $exists > 0 ) {
			return true;
		}
		return false !== $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}" );
	}
}
